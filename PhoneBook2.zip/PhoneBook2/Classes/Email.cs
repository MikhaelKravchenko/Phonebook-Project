﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace PhoneBook2.Classes
{
    public class Email
    {
        private int _Id = 0;
        private int _iContactId = 0;
        private int _iEmailTypeId = 0;
        private string _sEmailAddress = string.Empty;
        private int _iUser_ID = 0;

        public Email()
        {
        }

        public int ID
        {
            get { return _Id; }
            set { _Id = value; }
        }
        public int ContactId
        {
            get { return _iContactId; }
            set { _iContactId = value; }
        }
        public int EmailTypeId
        {
            get { return _iEmailTypeId; }
            set { _iEmailTypeId = value; }
        }
        public string EmailAddress  
        {
            get { return _sEmailAddress; }
            set { _sEmailAddress = value; }
        }

        public int User_ID
        {
            get { return _iUser_ID; }
            set { _iUser_ID = value; }
        }

        public DataTable GetEmails()
        {
            DataTable dt = new DataTable();
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_GET_EMAILS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.SelectCommand = cm;
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public int InsertEmails()
        {
            int iResult = 0;
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_INSERT_EMAILS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    cm.Parameters.Add("@EMAIL_TYPE_ID", SqlDbType.Int).Value = _iEmailTypeId;
                    cm.Parameters.Add("@EMAIL_ADDRESS", SqlDbType.NVarChar, 50).Value = _sEmailAddress;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;

                    SqlParameter pm_new_id = new SqlParameter("@NEW_ID", SqlDbType.Int, 4);
                    pm_new_id.Direction = ParameterDirection.Output;
                    cm.Parameters.Add(pm_new_id);
                    
                    
                    cm.ExecuteNonQuery();
                    iResult = Convert.ToInt32(pm_new_id.Value);
                }
            }
            return iResult; 
        
        }

        public void UpdateEmail()
        {
            string sConString = string.Empty;            
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString(); ;
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_UPDATE_EMAILS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@ID", SqlDbType.Int).Value = _Id;
                    cm.Parameters.Add("@EMAIL_TYPE_ID", SqlDbType.Int).Value = _iEmailTypeId;
                    cm.Parameters.Add("@EMAIL_ADDRESS", SqlDbType.NVarChar, 50).Value = _sEmailAddress;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                    cm.ExecuteNonQuery();
                }
            }
        }
        public void DeleteEmails()
        {
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_DELETE_EMAILS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@ID", SqlDbType.Int).Value = _Id;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                    cm.ExecuteNonQuery();
                }
            }
        }

        public DataTable GetEmailTypes()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_EMAILS_TYPES", cn))
                {
                    cm.CommandType = CommandType.StoredProcedure;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }


            return dt;
        }



        public DataTable GetEmailsByContactId()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_EMAILS_BY_CONTACT_ID", cn))
                {

                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }
            

            return dt;
        }

        public DataTable GetEmailsByEmailsId()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_EMAILS_BY_ID", cn))
                {

                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@EMAIL_ID", SqlDbType.Int).Value = _Id;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }


            return dt;
        }
    


    }
}
