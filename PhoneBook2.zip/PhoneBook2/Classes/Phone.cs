﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace PhoneBook2.Classes
{
    public class Phone
    {
        private int _Id = 0;
        private int _iContactId = 0;
        private int _iPhoneTypeId = 0;
        private string _sPhoneNumber = string.Empty;
        private int _iUser_ID = 0;

        public Phone()
        {
        }

        public int ID
        {
            get { return _Id; }
            set { _Id = value; }
        }
        public int ContactId
        {
            get { return _iContactId; }
            set { _iContactId = value; }
        }
        public int PhoneTypeId
        {
            get { return _iPhoneTypeId; }
            set { _iPhoneTypeId = value; }
        }
        public string PhoneNumber
        {
            get { return _sPhoneNumber; }
            set { _sPhoneNumber = value; }
        }

        public int User_ID
        {
            get { return _iUser_ID; }
            set { _iUser_ID = value; }
        }

        public DataTable GetPhones()
        {
            

            DataTable dt = new DataTable();
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_GET_PHONES", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.SelectCommand = cm;
                        da.Fill(dt);
                    }
                }
            }
            return dt;         
        }
      

        public int InsertPhone()
        {
            int iResult = 0;
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_INSERT_PHONES", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    cm.Parameters.Add("@PHONE_TYPE_ID", SqlDbType.Int).Value = _iPhoneTypeId;
                    cm.Parameters.Add("@PHONE_NUMBER", SqlDbType.NVarChar, 50).Value = _sPhoneNumber;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                  //  cm.ExecuteNonQuery();

                    SqlParameter pm_new_id = new SqlParameter("@NEW_ID", SqlDbType.Int, 4);
                    pm_new_id.Direction = ParameterDirection.Output;
                    cm.Parameters.Add(pm_new_id);

                    //  int iRetValue = 0;
                    cm.ExecuteNonQuery();
                    //iRetValue is ID of inserted Contact
                    iResult = Convert.ToInt32(pm_new_id.Value);
                }
            }
            return iResult;        
        }
        
        public void UpdatePhone()
        {
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString(); ;
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_UPDATE_PHONES", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@ID", SqlDbType.Int).Value = _Id;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    cm.Parameters.Add("@PHONE_TYPE_ID", SqlDbType.Int).Value = _iPhoneTypeId;
                    cm.Parameters.Add("@PHONE_NUMBER", SqlDbType.NVarChar, 50).Value = _sPhoneNumber;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                    cm.ExecuteNonQuery();
                }
            }
        }
        public void DeletePhone()
        {
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_DELETE_PHONES", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@ID", SqlDbType.Int).Value = _Id;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                    cm.ExecuteNonQuery();
                }
            }
        }

        public  DataTable GetPhoneTypes()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_PHONE_TYPES", cn))
                {
                    cm.CommandType = CommandType.StoredProcedure;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }
            

            return dt;
        }

        public  DataTable GetPhoneByContactId()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_PHONE_BY_CONTACT_ID", cn))
                {
                  
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }


            return dt;
        }



        public DataTable GetPhoneByPhoneId()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_PHONE_BY_ID", cn))
                {

                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@Phone_ID", SqlDbType.Int).Value = _Id;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }

            
            return dt;
        }
    
    
    }
}
