﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
namespace PhoneBook2
{
    public class SQLConnections
    {
       
    private string _sConnectionStringFNETIntern01= @"Data Source=sqldevf\sqldevf; initial catalog=FNETIntern01; user id=FNETUser; password=fnetdev;";
    private string _sConnectionStringFNETIntern02 = @"Data Source=sqldevf\sqldevf; initial catalog=FNETIntern02; user id=FNETUser; password=fnetdev;";
    private string _sConnectionStringFNETIntern03 = @"Data Source=sqldevf\sqldevf; initial catalog=FNETIntern03; user id=FNETUser; password=fnetdev;";

         public SQLConnections()
         {
         }

         public string ConnStringFNETInern01 {
             get { return _sConnectionStringFNETIntern01; }
             set { _sConnectionStringFNETIntern01 =value;}
         }
         public string ConnStringFNETInern02
         {
             get { return _sConnectionStringFNETIntern02; }
             set { _sConnectionStringFNETIntern02 = value; }
         }
         public string ConnStringFNETInern03
         {
             get { return _sConnectionStringFNETIntern03; }
             set { _sConnectionStringFNETIntern03 = value; }
         }

         public string GetSqlConnectionString() {
             string sDBName = string.Empty;
             string sResult = string.Empty;

             sDBName = System.Configuration.ConfigurationManager.AppSettings["DbName"].ToString();
           
             switch (sDBName) { 
                 case "FNETIntern01":
                     sResult = _sConnectionStringFNETIntern01;
                     break;
                 case "FNETIntern02":
                     sResult = _sConnectionStringFNETIntern02;
                     break;
                 case  "FNETIntern03":
                     sResult =_sConnectionStringFNETIntern03 ;
                     break;
             }
             return sResult;
         }
    }
    
}