﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace PhoneBook2.Classes
{
    public class Address
    {
        private int _Id = 0;
        private int _iContactId = 0;
        private int _iAddressTypeId = 0;
        private string _sAddress_1 = string.Empty;
        private string _sAddress_2 = string.Empty;
        private int _StateId = 0;
        private string _sCity = string.Empty;
        private string _sZip = string.Empty;
        private int _iUser_ID = 0;

        public Address()
        {
        }

        public int ID
        {
            get { return _Id; }
            set { _Id = value; }
        }
        public int ContactId
        {
            get { return _iContactId; }
            set { _iContactId = value; }
        }
        public int AddressTypeId
        {
            get { return _iAddressTypeId; }
            set { _iAddressTypeId = value; }
        }
        public string Address_1
        {
            get { return _sAddress_1; }
            set { _sAddress_1 = value; }
        }
        public string Address_2
        {
            get { return _sAddress_2; }
            set { _sAddress_2 = value; }
        }
        public int StateId
        {
            get { return _StateId; }
            set { _StateId = value; }
        }
        public string City
        {
            get { return _sCity; }
            set { _sCity = value; }
        }
        public string sZip
        {
            get { return _sZip; }
            set { _sZip = value; }
        }
        public int User_ID
        {
            get { return _iUser_ID; }
            set { _iUser_ID = value; }
        }


        public DataTable GetAddress()
        {
            DataTable dt = new DataTable();
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_GET_ADDRESS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.SelectCommand = cm;
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        public int InsertAddress()
        {
            int iResult = 0; ;
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_INSERT_ADDRESS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    cm.Parameters.Add("@ADDRESS_TYPE_ID", SqlDbType.Int).Value = _iAddressTypeId;
                    cm.Parameters.Add("@ADDRESS_1", SqlDbType.NVarChar, 50).Value = _sAddress_1;
                    cm.Parameters.Add("@ADDRESS_2", SqlDbType.NVarChar, 50).Value = _sAddress_2;
                    cm.Parameters.Add("@STATE_ID", SqlDbType.Int).Value = _StateId;
                    cm.Parameters.Add("@CITY", SqlDbType.NVarChar, 50).Value = _sCity;
                    cm.Parameters.Add("@ZIP", SqlDbType.NVarChar, 10).Value = _sZip;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                    cm.ExecuteNonQuery();

                    SqlParameter pm_new_id = new SqlParameter("@NEW_ID", SqlDbType.Int, 4);
                    pm_new_id.Direction = ParameterDirection.Output;
                    cm.Parameters.Add(pm_new_id);

                    //  int iRetValue = 0;
                    cm.ExecuteNonQuery();
                    //iRetValue is ID of inserted Contact
                    iResult = Convert.ToInt32(pm_new_id.Value);


                }
            }
            return iResult;
        }

        public void UpdateAddress()
        {
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString(); ;
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_UPDATE_ADDRESS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@ID", SqlDbType.Int).Value = _Id;
                    cm.Parameters.Add("@ADDRESS_TYPE_ID", SqlDbType.Int).Value = _iAddressTypeId;
                    cm.Parameters.Add("@ADDRESS_1", SqlDbType.NVarChar, 50).Value = _sAddress_1;
                    cm.Parameters.Add("@ADDRESS_2", SqlDbType.NVarChar, 50).Value = _sAddress_2;
                    cm.Parameters.Add("@STATE_ID", SqlDbType.Int).Value = _StateId;
                    cm.Parameters.Add("@CITY", SqlDbType.NVarChar, 50).Value = _sCity;
                    cm.Parameters.Add("@ZIP", SqlDbType.NVarChar, 10).Value = _sZip;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                    cm.ExecuteNonQuery();
                }
            }
        }
        public void DeleteAddress()
        {
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            SqlCommand cm;
            using (SqlConnection sqlcon = new SqlConnection(sConString))
            {
                using (cm = new SqlCommand("USP_PB_DELETE_ADDRESS", sqlcon))
                {
                    sqlcon.Open();
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@ID", SqlDbType.Int).Value = _Id;
                    cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                    cm.ExecuteNonQuery();
                }
            }
        }

        public DataTable GetAddressType()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_ADDRESS_TYPES", cn))
                {
                    cm.CommandType = CommandType.StoredProcedure;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }

            return dt;
        }

        public DataTable GetAddressByContactId()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_ADDRESS_BY_CONTACT_ID", cn))
                {

                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@CONTACT_ID", SqlDbType.Int).Value = _iContactId;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }


            return dt;
        }


        public DataTable GetAddressByAddressId()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_ADDRESS_BY_ID", cn))
                {

                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.Add("@ADDRESS_ID", SqlDbType.Int).Value = _Id;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);

                    }
                }
            }


            return dt;
        }
        // COMPLETE THIS PART, DO THE SP FOR IT. THEN DO THE FRONT END.
        public void GetState()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon = new SQLConnections();
            string sCnString = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnString))
            {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_STATE", cn))
                {
                    cm.CommandType = CommandType.StoredProcedure;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm))
                    {
                        da.Fill(dt);
                    }


                }
            }
        }
    }
}



// 5/11 - continue here to check if State needs any more sections.
         //public void GetStateByStateId()