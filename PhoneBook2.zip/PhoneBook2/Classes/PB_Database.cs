﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace PhoneBook2.Classes
{
    public static  class PB_Database
    {

        public static DataTable GetContactType()
        {
            DataTable dt = new DataTable();
            SQLConnections sqlcon=new SQLConnections();
            string sCnstring = sqlcon.GetSqlConnectionString();

            using (SqlConnection cn = new SqlConnection(sCnstring)) {
                using (SqlCommand cm = new SqlCommand("USP_PB_GET_CONTACT_TYPES", cn)) {
                    cm.CommandType = CommandType.StoredProcedure;
                    cn.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cm)) {
                        da.Fill(dt);

                    }
                }
            }

          
            return dt;
        }
    }
}