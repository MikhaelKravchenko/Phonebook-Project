﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace PhoneBook2.Classes
{
    public class Contact
    {
        private int _id = 0;
        private string _sFirstName = string.Empty;
        private string _sLastName = string.Empty;
        private DateTime _dDOB;
        private int _personTypeId = 0;
        private int _iUser_ID = 0;


        public Contact()
        {
        }

        public int ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public int PersonTypeId
        {
            get { return _personTypeId; }
            set { _personTypeId = value; }
        }

        public string FirstName
        {
            get { return _sFirstName; }
            set { _sFirstName = value; }
        }
        public string LastName
        {
            get { return _sLastName; }
            set { _sLastName = value; }
        }

        public DateTime DOB
        {
            get { return _dDOB; }
            set { _dDOB = value; }
        }


        public int USER_ID
        {
            get { return _iUser_ID; }
            set { _iUser_ID = value; }
        }
    


        public int UpdateContact()
        {
            int iResult = 0;
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            // sConString = @"Data Source=sqldevf\sqldevf; initial catalog=FNETIntern01; user id=FNETUser; password=fnetdev;";

            try
            {
                using (SqlConnection cn = new SqlConnection(sConString))
                {

                    using (SqlCommand cm = new SqlCommand("USP_PB_UPDATE_PB_CONTACTS", cn))
                    {
                        cm.CommandType = CommandType.StoredProcedure;
                        cm.Connection.Open();


                        cm.Parameters.Add("ID", SqlDbType.Int, 4).Value = _id;
                        cm.Parameters.Add("@FIRST_NM", SqlDbType.VarChar, 50).Value = _sFirstName;
                        cm.Parameters.Add("@LAST_NM", SqlDbType.VarChar, 50).Value = _sLastName;
                        cm.Parameters.Add("@CONTACT_TYPE_ID", SqlDbType.Int, 4).Value = _personTypeId;
                        cm.Parameters.Add("@DOB", SqlDbType.Date, 8).Value = _dDOB;
                        cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;
                        

                                                                 
                        //SqlParameter pm_new_id = new SqlParameter("@NEW_ID", SqlDbType.Int, 4);
                        //pm_new_id.Direction = ParameterDirection.Output;
                        //cm.Parameters.Add(pm_new_id);

                        //  int iRetValue = 0;
                        cm.ExecuteNonQuery();
                        //iRetValue is ID of inserted Contact
                        //iResult = Convert.ToInt32(pm_new_id.Value);
                    }
                }

          

                return iResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public void DeleteContact()
        {
            string sConString = string.Empty;
            SQLConnections SQLCon = new SQLConnections();
            sConString = SQLCon.GetSqlConnectionString();
            try
            {
                using (SqlConnection cn = new SqlConnection(sConString))
                {
                    using (SqlCommand cm = new SqlCommand("USP_PB_DELETE_PB_CONTACT", cn))
                    {
                        cn.Open();
                        cm.CommandType = CommandType.StoredProcedure;
                        cm.Parameters.Add("ID", SqlDbType.Int, 4).Value = _id;
                        cm.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    

        public DataTable GetPersonType()
        {
            DataTable dt = new DataTable();
            string sConstring = string.Empty;
            SQLConnections SQLCon = new SQLConnections();
            sConstring = SQLCon.GetSqlConnectionString();

            //string sGetPersonType = string.Empty;
            //sGetPersonType = @"Data Source=sqldevf\sqldevf; initial catalog=FNETIntern01; user id=FNETUser; password=fnetdev;";
            try
            {
                using (SqlConnection cn = new SqlConnection(sConstring))
                {

                    using (SqlCommand cm = new SqlCommand("USP_PB_GET_CONTACT_TYPES", cn))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter())
                        {
                            cm.CommandType = CommandType.StoredProcedure;

                            cm.Connection.Open();

                            da.SelectCommand = cm;
                            da.Fill(dt);


                            return dt;
                        }

                    }

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public DataTable GetContacts()
        {
            DataTable dt = new DataTable();

            string sConstring = string.Empty;
            SQLConnections SQLCon = new SQLConnections();
            sConstring = SQLCon.GetSqlConnectionString();
            try
            {
                using (SqlConnection cn = new SqlConnection(sConstring))
                {

                    using (SqlCommand cm = new SqlCommand("USP_PB_GET_CONTACTS", cn))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter())
                        {
                            cm.CommandType = CommandType.StoredProcedure;

                            cm.Connection.Open();

                            cm.Parameters.Add("@FIRST_NM", SqlDbType.NVarChar, 50).Value = _sFirstName;
                            cm.Parameters.Add("@LAST_NM", SqlDbType.NVarChar, 50).Value = _sLastName;
                            cm.Parameters.Add("@CONTACT_TYPE_ID", SqlDbType.NVarChar, 3).Value = _personTypeId;
                            if (_dDOB.Equals(DateTime.MinValue))
                            {
                                cm.Parameters.Add("@DOB", SqlDbType.NVarChar, 10).Value = DBNull.Value;
                            }
                            else {
                                cm.Parameters.Add("@DOB", SqlDbType.NVarChar, 10).Value =_dDOB.ToShortDateString();
                            }

                            da.SelectCommand = cm;
                            da.Fill(dt);
                            return dt;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetContact_BYId()
        {
            DataTable dt = new DataTable();
            //   sGetContact_BYId = @"Data Source=sqldevf\sqldevf; initial catalog=FNETIntern01; user id=FNETUser; password=fnetdev;";
            string sConstring = string.Empty;
            SQLConnections SQLCon = new SQLConnections();
            sConstring = SQLCon.GetSqlConnectionString();
            try
            {
                using (SqlConnection cn = new SqlConnection(sConstring))
                {

                    using (SqlCommand cm = new SqlCommand("USP_PB_GET_CONTACTS_BY_ID", cn))
                    {
                        using (SqlDataAdapter da = new SqlDataAdapter())
                        {
                            cm.CommandType = CommandType.StoredProcedure;

                            cm.Connection.Open();

                            cm.Parameters.Add("@ID", SqlDbType.Int, 4).Value = _id;
                            da.SelectCommand = cm;
                            da.Fill(dt);
                            return dt;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }



        }


        public int InsertContact()
        {
            int iResult = 0;
            string sConString = string.Empty;
            SQLConnections SQLcon = new SQLConnections();
            sConString = SQLcon.GetSqlConnectionString();
            // sConString = @"Data Source=sqldevf\sqldevf; initial catalog=FNETIntern01; user id=FNETUser; password=fnetdev;";

            try
            {
                using (SqlConnection cn = new SqlConnection(sConString))
                {

                    using (SqlCommand cm = new SqlCommand("USP_PB_INSERT_CONTACTS", cn))
                    {
                        cm.CommandType = CommandType.StoredProcedure;
                        cm.Connection.Open();


                        cm.Parameters.Add("@FIRST_NM", SqlDbType.VarChar, 50).Value = _sFirstName;
                        cm.Parameters.Add("@LAST_NM", SqlDbType.VarChar, 50).Value = _sLastName;
                        cm.Parameters.Add("@CONTACT_TYPE_ID", SqlDbType.Int, 4).Value = _personTypeId;
                        cm.Parameters.Add("@DOB", SqlDbType.Date, 8).Value = _dDOB;
                        cm.Parameters.Add("@USER_ID", SqlDbType.Int, 4).Value = _iUser_ID;




                        SqlParameter pm_new_id = new SqlParameter("@NEW_ID", SqlDbType.Int, 4);
                        pm_new_id.Direction = ParameterDirection.Output;
                        cm.Parameters.Add(pm_new_id);

                        //  int iRetValue = 0;
                        cm.ExecuteNonQuery();
                        //iRetValue is ID of inserted Contact
                        iResult = Convert.ToInt32(pm_new_id.Value);
                    }
                }

                return iResult;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }      

    }
}
